clear
rm ./install.sh
rm ./intro.sh
rm ./loading.sh
browser="$1"
url="$2"
echo JUNAID BROWSER OPENER, version 0.1 relesed on july 30.
echo You want help to start type : ./help.sh
start $1 $2
