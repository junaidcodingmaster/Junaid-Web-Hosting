clear
echo ---------------------------------------------------------------------------------------------------------
echo Tips : 
echo        For opening browser you want to type ./jbopener --browser-- 
echo        For opening url you want to type ./jbopener --browser-- --url--
echo        If you not entered browser name it will automaticly reject to your defualt browser.
echo -----------------------------------------------------------------------------------------------------------
echo If you are using windows you donot have git bash are terminal softwere.
echo Donot worry you want to press windowsLogo + r type cmd. 
echo when cmd is open type bash intro.sh or bash install.sh 
echo  How to open/start apps/browser in android.
echo Download termux app from play store or Download it from froid.com
echo After installing type clear.
echo then type apt update && apt upgrade
echo then type pkg install w3m
echo then type w3m --url--
echo If you still not understand go to : https://www.learntermux.tech/2020/01/best-way-to-browser-internet-using-Termux-on-Android-2020.html
echo JUNAID BROWSER OPENER by Junaid.
echo type ./jbopener.sh
