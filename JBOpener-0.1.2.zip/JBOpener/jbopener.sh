clear

browser="$1"
url="$2"
echo JUNAID BROWSER OPENER, version 0.1.2 Released on July 31 2021.
echo You want help to start type : ./help.sh 
echo ./help.sh automatically solve the problem. Made By Junaid.
start $1 $2
