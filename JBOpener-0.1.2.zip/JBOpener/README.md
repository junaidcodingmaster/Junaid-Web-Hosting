# Junaid Browser Opener
Junaid Browser Opener is made for developers, sometimes we want to speed-up , we don't want to search the apps. So, I made it all can type a commard line and done. Junaid Browser Opener is made by Junaid.

<br></br>

In Junaid Browser Opener you want to type ` ./jbopener --browser-- -url- `

Example : ` ./jbopener chrome github.com ` This will open chrome and reject to given url.

<br></br>

## How to use JBOpener in CMD
CMD not support to this terminal.
because now the latest version of CMD.exe is there in windows.

So , I suggest some ways to open and run this terminal.
- you want to download git on your computer.
- - Git for Windows [www.gitforwindows.org](www.gitforwindows.org)
- - Git for Mac [www.gitformac.org](https://www.google.com/search?q=git+for+mac)
- - Git for Linux ` sudo pkg install git `

<br></br>

## How to JBOpener in Termux
- Download Termux from [F-Droid.org](https://f-droid.org/packages/com.termux/)
- After installing Type ` pkg install git ` 
- type ` git clone https://github.com/junaidcodingmaster/Junaid-Browser-Opener-for-termux.git `
- type ` cd Junaid-Browser-Opener-for-termux `
- Now ready you can use Junaid Browser Opener on android.
But In android some differents have. Like you want to type ` bash jbopener.sh --URL-- ` , 
Example : ` bash jbopener.sh www.google.com ` , In android this terminal not open browser it open webview in Termux.

<br></br>

## How To Download JBOpener 
You can download JBopener in two ways :
- [Download using Git Bash or CMD](#download-using-git-bash-or-cmd)
- Download by using JBOpener.zip

### Download using Git Bash or CMD
- Git Bash
- CMD

If you have Git Bash type this commard lines :
- type ` git clone https://github.com/junaidcodingmaster/Junaid-Browser-Opener-for-termux.git `
- type ` cd Junaid-Browser-Opener-for-termux `
Your done with this. Now you want to type ` ./intro.sh `
- next you want to type ` ./install.sh `
- It will automatically reject to ` ./jbopener.sh `
And your done Jbopener has installed on your computer.
- **Next time onwards you want to type ** ` ./jbopener.sh -browser- -URL-

### Download by using JBOpener.zip
Download a zip from this url []()


> This is Update version of Junaid Browser Opener