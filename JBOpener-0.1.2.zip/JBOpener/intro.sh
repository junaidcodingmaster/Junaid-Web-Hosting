clear
echo Welcome to Junaid Browser Opener, made by Junaid , this terminal helps us to open any browser by using commard lines.
echo You can open any browser with url : example jbopener.sh --browser_name-- --url--
echo This terminal supports : windows , apple and linux
echo this terminal also supports termux.
echo Junaid Browser Opener - Made By Junaid.
echo If you have any problem with Jbopener.sh go to help.sh
echo it will automatically solve the problem.
echo this is Intro of Junaid browser Opener.
echo -------------------------------------------------
echo type ./install.sh
echo -------------------------------------------------
echo to install jbopener latest verson.